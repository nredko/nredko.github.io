---
name: process-exporter
tools: [Go, K8S, Linux]
image: /assets/img/grafana.png
description: Kubernetes pod name resolver for process-exporter
external_url: https://github.com/opvizor/process-exporter
---
