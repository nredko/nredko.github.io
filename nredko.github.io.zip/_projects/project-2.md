---
name: Set game
tools: [JS, NSIS]
image: https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Set-game-cards.png/250px-Set-game-cards.png
description: Standalone or online SET card game
---

# SET game

This classic [Set cards game](https://en.wikipedia.org/wiki/Set_(card_game)) was designed for my kids.

![](/assets/img/set.png)

<p class="text-center">
{% include button.html link="http://nredko.github.io/set" text="Play now" %}
</p>