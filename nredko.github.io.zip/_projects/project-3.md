---
name: OpBot
tools: [CoffeeScript, TypeScript, VMware API]
image: http://www.opvizor.com/wp-content/uploads/2016/11/vmwintable.png
description: Slack bot for VMWare management
---

# OpBot

Slack bot which allows you to manage VMWare infrastructure. Made for [Opvizor](https://www.opvizor.com/).

![](http://www.opvizor.com/wp-content/uploads/2016/11/vmwintable.png)

Sources are closed, [documentation is available](https://opvizor.atlassian.net/wiki/spaces/OPBOT/pages/73400386/Background)