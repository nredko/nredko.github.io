---
name: CodeNotary
tools: [Analysis]
image: /assets/img/codenotary.png
description: I'm proud that analysis I've made for vChain Inc. was used in creation of such great service.
external_url: http://codenotary.io
---
